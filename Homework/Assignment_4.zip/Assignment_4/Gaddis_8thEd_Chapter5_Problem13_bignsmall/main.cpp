/* 
 * File:   main.cpp
 * Author: Joshua Duque
 * Created on 7-10-17
 * Purpose: use loop to determine largest integer and smallest integer inputted
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here

int main(int argc, char** argv) {
    //Declare all Variables Here
    int num,max=0,min=0;
    
    count<<"Enter any amount of integers. Enter -99 to exit and i will tell you"
            " the largeest and smallest integer you entered."<<endl;
    while(num!=-99)
    {
        cout<<"Enter number"<<endl;
        cin>>num;
        
    }
             
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    
    //Exit
    return 0;
}

  