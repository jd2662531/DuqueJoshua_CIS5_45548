/* 
 * File:   main.cpp
 * Author: Joshua Duque
 * Created on 7-17-17
 * Purpose:  Determine if its a prime number 

//System Libraries Here
 #include <iostream>
#include <iomanip>
using namespace std;

//function prototype
bool isPrime(int);

int main(int argc, char** argv)
{
    int number;
    cout << "Enter a number to find out if it's prime or not: ";
    cin >> number;
    
    if(isPrime(number))
        cout << "The number " << number << " is prime.\n";
    else 
        cout << "The number " << number << " is not prime.\n";
    
    return 0;
}
bool isPrime(int number){
    int i;
    for(i=2; i<number; i++){
        if(number % i == 0){
            return false;
        }//end inner if
    }//end outer if
}//end bool isPrime function